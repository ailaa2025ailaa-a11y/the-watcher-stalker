execute positioned ^ ^ ^-5 run playsound minecraft:entity.zombie.attack_wooden_door ambient @s ~ ~ ~ 2 0.8
execute positioned ^ ^ ^-5 run playsound minecraft:entity.zombie.attack_wooden_door ambient @s ~ ~ ~ 2 0.9
execute positioned ^ ^ ^-5 run playsound minecraft:block.wooden_door.close ambient @s ~ ~ ~ 2 0.6
