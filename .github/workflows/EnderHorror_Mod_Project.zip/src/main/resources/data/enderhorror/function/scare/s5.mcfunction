execute unless entity @e[type=minecraft:enderman,tag=eh_watcher] positioned ^ ^ ^14 run summon minecraft:enderman ~ ~ ~ {NoAI:1b,Silent:1b,Invulnerable:1b,PersistenceRequired:1b,Tags:["eh_watcher"],CustomName:{text:"???",color:"dark_red"}}
playsound minecraft:entity.enderman.stare ambient @s ~ ~ ~ 1.5 0.6
