tellraw @s {text:"Herobrine joined the game",color:"yellow"}
playsound minecraft:entity.wither.ambient ambient @s ~ ~ ~ 0.6 0.5
