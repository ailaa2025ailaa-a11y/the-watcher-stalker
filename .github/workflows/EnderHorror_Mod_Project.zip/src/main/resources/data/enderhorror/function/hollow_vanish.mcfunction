tellraw @a[distance=..40] {text:"<???> not yet...",color:"dark_red"}
particle minecraft:large_smoke ~ ~1 ~ 0.3 1 0.3 0.05 40
kill @s
