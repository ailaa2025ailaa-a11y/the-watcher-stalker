scoreboard players add @s eh_life 1
tp @s ~ ~ ~ facing entity @p
execute if entity @p[distance=..7] run function enderhorror:watcher_caught
execute if score @s eh_life matches 300.. run function enderhorror:watcher_vanish
