execute as @p[distance=..7] run function enderhorror:scare/jumpscare
particle minecraft:large_smoke ~ ~1 ~ 0.3 1 0.3 0.05 40
kill @s
