execute store result score @s eh_r run random value 1..8
execute if predicate enderhorror:one_in_6 unless entity @e[type=minecraft:enderman,tag=eh_hollow] run scoreboard players set @s eh_r 9
execute if score @s eh_r matches 1 run function enderhorror:scare/s1
execute if score @s eh_r matches 2 run function enderhorror:scare/s2
execute if score @s eh_r matches 3 run function enderhorror:scare/s3
execute if score @s eh_r matches 4 run function enderhorror:scare/s4
execute if score @s eh_r matches 5 run function enderhorror:scare/s5
execute if score @s eh_r matches 6 run function enderhorror:scare/s6
execute if score @s eh_r matches 7 run function enderhorror:scare/s7
execute if score @s eh_r matches 8 run function enderhorror:scare/s8
execute if score @s eh_r matches 9 run function enderhorror:scare/s9
