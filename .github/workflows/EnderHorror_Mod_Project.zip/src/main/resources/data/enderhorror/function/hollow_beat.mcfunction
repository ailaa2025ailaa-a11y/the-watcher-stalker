scoreboard players set @s eh_beat 0
execute if entity @a[distance=..35] run playsound minecraft:entity.warden.heartbeat hostile @a[distance=..35] ~ ~ ~ 4 1
execute if entity @a[distance=..35] run playsound minecraft:block.stone.step hostile @a[distance=..35] ~ ~ ~ 2 0.5
execute if entity @a[distance=..16] run playsound minecraft:entity.warden.nearby_close hostile @a[distance=..16] ~ ~ ~ 3 0.7
execute if entity @a[distance=..10] run playsound minecraft:entity.enderman.scream hostile @a[distance=..10] ~ ~ ~ 2 0.5
