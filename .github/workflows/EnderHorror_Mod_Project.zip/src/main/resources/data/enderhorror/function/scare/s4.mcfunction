function enderhorror:scare/jumpscare
