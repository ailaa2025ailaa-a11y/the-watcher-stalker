particle minecraft:large_smoke ~ ~1 ~ 0.3 1 0.3 0.05 30
kill @s
