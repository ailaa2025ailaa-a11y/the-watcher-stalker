execute at @s run function enderhorror:scare/pick
