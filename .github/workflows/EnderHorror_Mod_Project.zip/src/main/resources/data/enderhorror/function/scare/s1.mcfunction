execute positioned ^ ^ ^-4 run playsound minecraft:block.gravel.step ambient @s ~ ~ ~ 1.5 0.7
execute positioned ^ ^ ^-3 run playsound minecraft:block.gravel.step ambient @s ~ ~ ~ 1.5 0.75
execute positioned ^ ^ ^-2 run playsound minecraft:block.gravel.step ambient @s ~ ~ ~ 1.5 0.8
execute positioned ^ ^ ^-1.5 run playsound minecraft:block.stone.step ambient @s ~ ~ ~ 1.5 0.6
