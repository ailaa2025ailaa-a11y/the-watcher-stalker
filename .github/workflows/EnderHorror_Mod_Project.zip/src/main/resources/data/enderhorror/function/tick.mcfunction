execute if score #level eh_level matches 1 as @a[gamemode=!spectator] if predicate enderhorror:chance_low at @s run function enderhorror:scare/pick
execute if score #level eh_level matches 2 as @a[gamemode=!spectator] if predicate enderhorror:chance_mid at @s run function enderhorror:scare/pick
execute if score #level eh_level matches 3 as @a[gamemode=!spectator] if predicate enderhorror:chance_high at @s run function enderhorror:scare/pick
execute as @e[type=minecraft:enderman,tag=eh_watcher] at @s run function enderhorror:watcher_tick
execute as @e[type=minecraft:enderman,tag=eh_hollow] at @s run function enderhorror:hollow_tick
